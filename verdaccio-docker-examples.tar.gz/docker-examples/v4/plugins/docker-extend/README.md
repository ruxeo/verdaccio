# How to extend an Verdaccio Docker image?

Depends of your version the approach is different, please check each version.
