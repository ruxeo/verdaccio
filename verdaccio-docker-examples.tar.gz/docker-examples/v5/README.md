# Verdaccio 5

> Before run examples, build the local image by running `pnpm docker`.

- [Docker + Nginx + Verdaccio](reverse_proxy/nginx/README.md)

## Using Plugins with Docker

List of different approaches

> Note these options could be improved, feel free to submit upgrades

- [Docker + Install plugins from a registry](plugins/docker-build-install-plugin/README.md)
- [Docker + Install local plugin](plugins/docker-local-plugin/README.md)
