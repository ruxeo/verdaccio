Example taken from:

[https://github.com/foxylion/docker-nginx-self-signed-https](https://github.com/foxylion/docker-nginx-self-signed-https)

by [@foxylion](https://github.com/foxylion)
